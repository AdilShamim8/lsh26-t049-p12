'use client';

import { useMemo, useState } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { toast } from '@/hooks/use-toast';
import {
  Target,
  Plus,
  Sparkles,
  TriangleAlert,
  CalendarCheck2,
  Landmark,
  Pencil,
  Loader2,
  ScissorsLineDashed,
  CheckCircle2,
} from 'lucide-react';
import {
  computeDps,
  DPS_METHOD,
  formatBDT,
  formatDateLabel,
  type MonthSummary,
  type PocketProjection,
} from '@/lib/engine';

export function PocketsView({
  summary,
  salaryPaisa,
  projections,
  baseProjections,
  cuts,
  setCuts,
  whatif,
  whatifApplied,
  setWhatifApplied,
  onCreatePocket,
  onPatchPocket,
  onDeletePocket,
}: {
  summary: MonthSummary;
  salaryPaisa: number;
  projections: PocketProjection[];
  baseProjections: PocketProjection[];
  cuts: Record<string, number>;
  setCuts: (c: Record<string, number>) => void;
  whatif: { savedPaisa: number; newProjectedSpendPaisa: number; newSurplusPaisa: number };
  whatifApplied: boolean;
  setWhatifApplied: (v: boolean) => void;
  onCreatePocket: (data: { name: string; itemDetails: string; targetPaisa: number; monthlyContributionPaisa: number; savedPaisa: number; dpsRate: number }) => Promise<void>;
  onPatchPocket: (id: number, data: Record<string, number | string>) => Promise<void>;
  onDeletePocket: (id: number) => Promise<void>;
}) {
  const [createOpen, setCreateOpen] = useState(false);
  const [cName, setCName] = useState('');
  const [cDetails, setCDetails] = useState('');
  const [cTarget, setCTarget] = useState('');
  const [cSaved, setCSaved] = useState('');
  const [cContrib, setCContrib] = useState('');
  const [cRate, setCRate] = useState('9.5');
  const [creating, setCreating] = useState(false);
  const [editContrib, setEditContrib] = useState<Record<number, string>>({});
  const [deposit, setDeposit] = useState<Record<number, string>>({});
  const [busyId, setBusyId] = useState<number | null>(null);

  const activeSurplus = whatifApplied ? whatif.newSurplusPaisa : summary.projectedLeftoverPaisa;
  const activePockets = useMemo(() => projections.filter(p => !p.completed), [projections]);
  const plannedTotal = activePockets.reduce((a, p) => a + p.plannedContributionPaisa, 0);
  const fundingPct = plannedTotal > 0 ? Math.min(100, Math.round((Math.max(0, activeSurplus) / plannedTotal) * 100)) : 0;
  const anyCut = Object.values(cuts).some(v => v > 0);
  const sliderCategories = summary.byCategory.slice(0, 6);

  async function handleCreate() {
    const target = Number.parseFloat(cTarget);
    const contrib = Number.parseFloat(cContrib);
    const saved = Number.parseFloat(cSaved || '0');
    const rate = Number.parseFloat(cRate || '9.5');
    if (!cName.trim()) return toast({ title: 'Pocket name is required', variant: 'destructive' });
    if (!Number.isFinite(target) || target <= 0) return toast({ title: 'Enter a valid target amount', variant: 'destructive' });
    if (!Number.isFinite(contrib) || contrib <= 0) return toast({ title: 'Enter a valid monthly contribution', variant: 'destructive' });
    if (!Number.isFinite(saved) || saved < 0) return toast({ title: 'Saved-so-far must be zero or more', variant: 'destructive' });
    setCreating(true);
    try {
      await onCreatePocket({
        name: cName.trim(),
        itemDetails: cDetails.trim(),
        targetPaisa: Math.round(target * 100),
        monthlyContributionPaisa: Math.round(contrib * 100),
        savedPaisa: Math.round(saved * 100),
        dpsRate: Number.isFinite(rate) ? rate : 9.5,
      });
      toast({ title: 'Pocket created', description: 'Its completion date is derived from the live forecast.' });
      setCreateOpen(false);
      setCName('');
      setCDetails('');
      setCTarget('');
      setCSaved('');
      setCContrib('');
    } finally {
      setCreating(false);
    }
  }

  async function saveContribution(p: PocketProjection) {
    const v = Number.parseFloat(editContrib[p.pocket.id] ?? '');
    if (!Number.isFinite(v) || v <= 0) return toast({ title: 'Enter a valid contribution', variant: 'destructive' });
    setBusyId(p.pocket.id);
    try {
      await onPatchPocket(p.pocket.id, { monthlyContributionPaisa: Math.round(v * 100) });
      toast({ title: 'Contribution updated', description: 'All completion dates just recalculated from the forecast.' });
      setEditContrib(s => ({ ...s, [p.pocket.id]: '' }));
    } finally {
      setBusyId(null);
    }
  }

  async function addDeposit(p: PocketProjection) {
    const v = Number.parseFloat(deposit[p.pocket.id] ?? '');
    if (!Number.isFinite(v) || v <= 0) return toast({ title: 'Enter a valid deposit amount', variant: 'destructive' });
    setBusyId(p.pocket.id);
    try {
      await onPatchPocket(p.pocket.id, { savedPaisa: p.pocket.savedPaisa + Math.round(v * 100) });
      toast({ title: 'Deposit added', description: 'Remaining target and completion date updated.' });
      setDeposit(s => ({ ...s, [p.pocket.id]: '' }));
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="space-y-5">
      {/* Surplus + what-if */}
      <div className="grid grid-cols-1 gap-5 xl:grid-cols-12">
        <Card className="rounded-2xl border-stone-200/80 shadow-sm xl:col-span-5">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <Landmark className="h-4 w-4 text-teal-700" /> Forecast surplus
            </CardTitle>
            <CardDescription>The money pockets are actually funded from</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-end justify-between rounded-xl bg-stone-50 px-4 py-3">
              <div>
                <p className="text-xs uppercase tracking-wide text-stone-400">
                  {whatifApplied && anyCut ? 'Scenario surplus' : 'Projected monthly surplus'}
                </p>
                <p className={`text-3xl font-bold tabular-nums ${activeSurplus >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                  {formatBDT(activeSurplus)}
                </p>
              </div>
              <p className="max-w-[55%] text-right text-xs leading-relaxed text-stone-500">
                salary {formatBDT(salaryPaisa)} − projected spend{' '}
                {formatBDT(whatifApplied && anyCut ? whatif.newProjectedSpendPaisa : summary.projectedSpendPaisa)}
              </p>
            </div>
            {activePockets.length > 0 && (
              <div>
                <div className="mb-1 flex items-center justify-between text-xs text-stone-500">
                  <span>Pockets plan {formatBDT(plannedTotal)}/month</span>
                  <span>
                    {fundingPct >= 100 ? 'fully funded by forecast' : `forecast funds ${fundingPct}% of the plan`}
                  </span>
                </div>
                <Progress value={fundingPct} className="h-2 bg-stone-100" />
                {fundingPct < 100 && (
                  <p className="mt-2 text-xs leading-relaxed text-amber-700">
                    The surplus is rationed proportionally across pockets — dates below are therefore{' '}
                    <b>later than the naive target ÷ contribution</b> math. That is the point: they are honest.
                  </p>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="rounded-2xl border-stone-200/80 shadow-sm xl:col-span-7">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <ScissorsLineDashed className="h-4 w-4 text-amber-600" /> What-if: cut a category…
              <Badge variant="outline" className="ml-auto font-normal text-stone-500">bonus · live scenario</Badge>
            </CardTitle>
            <CardDescription>Slide a cut and watch every pocket date move immediately</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {sliderCategories.length === 0 && <p className="text-sm text-stone-400">Add expenses first to unlock the what-if panel.</p>}
            {sliderCategories.map(c => (
              <div key={c.category} className="flex items-center gap-3">
                <span className="w-32 shrink-0 truncate text-sm text-stone-700">{c.category}</span>
                <Slider
                  value={[cuts[c.category] ?? 0]}
                  min={0}
                  max={50}
                  step={5}
                  onValueChange={([v]) => setCuts({ ...cuts, [c.category]: v })}
                  className="flex-1"
                  aria-label={`Cut ${c.category} by percent`}
                />
                <span className="w-14 shrink-0 text-right text-sm font-medium tabular-nums text-stone-700">
                  {cuts[c.category] ?? 0}%
                </span>
                <span className="w-24 shrink-0 text-right text-xs tabular-nums text-emerald-700">
                  {cuts[c.category] ? `−${formatBDT(Math.round((c.projectedPaisa * (cuts[c.category] ?? 0)) / 100))}` : ''}
                </span>
              </div>
            ))}
            {anyCut && (
              <div className="flex flex-wrap items-center gap-3 rounded-xl border border-teal-200 bg-teal-50/60 px-3 py-2 text-sm">
                <Sparkles className="h-4 w-4 text-teal-700" />
                <span className="text-teal-900">
                  Cutting saves <b>{formatBDT(whatif.savedPaisa)}</b>/month → surplus{' '}
                  <b>{formatBDT(whatif.newSurplusPaisa)}</b>
                </span>
                <label className="ml-auto flex items-center gap-2 text-xs text-stone-600">
                  <Switch checked={whatifApplied} onCheckedChange={setWhatifApplied} aria-label="Apply scenario to pocket dates" />
                  apply to dates
                </label>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-7 text-xs text-stone-500"
                  onClick={() => setCuts(Object.fromEntries(sliderCategories.map(c => [c.category, 0])))}
                >
                  reset
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Pocket cards */}
      <div className="flex items-center justify-between">
        <h2 className="flex items-center gap-2 text-lg font-semibold text-stone-800">
          <Target className="h-5 w-5 text-teal-700" /> Savings pockets
        </h2>
        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogTrigger asChild>
            <Button className="bg-teal-700 hover:bg-teal-800">
              <Plus className="h-4 w-4" /> New pocket
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>New savings pocket</DialogTitle>
              <DialogDescription>The completion date will be derived from the live forecast, not a naive formula.</DialogDescription>
            </DialogHeader>
            <div className="space-y-3">
              <div className="space-y-1.5">
                <Label htmlFor="c-name">Name</Label>
                <Input id="c-name" placeholder="e.g. Wedding Fund" value={cName} onChange={e => setCName(e.target.value)} maxLength={80} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="c-details">Item details</Label>
                <Input id="c-details" placeholder="What is it for?" value={cDetails} onChange={e => setCDetails(e.target.value)} maxLength={200} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label htmlFor="c-target">Target (৳)</Label>
                  <Input id="c-target" type="number" min="1" value={cTarget} onChange={e => setCTarget(e.target.value)} className="tabular-nums" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="c-saved">Saved so far (৳)</Label>
                  <Input id="c-saved" type="number" min="0" value={cSaved} onChange={e => setCSaved(e.target.value)} className="tabular-nums" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label htmlFor="c-contrib">Monthly contribution (৳)</Label>
                  <Input id="c-contrib" type="number" min="1" value={cContrib} onChange={e => setCContrib(e.target.value)} className="tabular-nums" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="c-rate">DPS rate (% p.a.)</Label>
                  <Input id="c-rate" type="number" min="0" max="100" step="0.1" value={cRate} onChange={e => setCRate(e.target.value)} className="tabular-nums" />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button onClick={handleCreate} disabled={creating} className="w-full bg-teal-700 hover:bg-teal-800">
                {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Create pocket'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {projections.length === 0 ? (
        <Card className="rounded-2xl border-dashed border-stone-300 bg-white/60 shadow-sm">
          <CardContent className="flex flex-col items-center gap-2 py-10 text-center">
            <Target className="h-8 w-8 text-stone-300" />
            <p className="text-sm text-stone-500">No savings pockets yet. Create one — its date will come from your forecast.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">
          {projections.map(p => {
            const pct = p.pocket.targetPaisa > 0 ? Math.min(100, Math.round((p.pocket.savedPaisa / p.pocket.targetPaisa) * 100)) : 0;
            const base = baseProjections.find(b => b.pocket.id === p.pocket.id);
            const scenarioDelta = base?.completionDate && p.completionDate && p.completionDate !== base.completionDate ? p : null;
            return (
              <Card key={p.pocket.id} className="flex flex-col rounded-2xl border-stone-200/80 shadow-sm">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <CardTitle className="truncate text-base">{p.pocket.name}</CardTitle>
                      <CardDescription className="mt-0.5 line-clamp-2">{p.pocket.itemDetails || 'Savings pocket'}</CardDescription>
                    </div>
                    <button
                      onClick={() => onDeletePocket(p.pocket.id)}
                      className="rounded-md px-1.5 py-1 text-[11px] text-stone-300 transition hover:bg-rose-50 hover:text-rose-600"
                      aria-label={`Delete ${p.pocket.name}`}
                    >
                      delete
                    </button>
                  </div>
                  <div className="mt-2">
                    <div className="mb-1 flex items-center justify-between text-xs text-stone-500">
                      <span className="font-medium tabular-nums text-stone-700">
                        {formatBDT(p.pocket.savedPaisa)} <span className="font-normal text-stone-400">of {formatBDT(p.pocket.targetPaisa)}</span>
                      </span>
                      <span className="tabular-nums">{pct}%</span>
                    </div>
                    <Progress value={pct} className="h-2 bg-stone-100" />
                  </div>
                </CardHeader>
                <CardContent className="flex flex-1 flex-col gap-3">
                  {p.completed ? (
                    <div className="flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-3 text-sm font-medium text-emerald-800">
                      <CheckCircle2 className="h-5 w-5" /> Target achieved — well done!
                    </div>
                  ) : p.stalled ? (
                    <div className="flex items-start gap-2 rounded-xl border border-rose-200 bg-rose-50 px-3 py-3 text-sm text-rose-900">
                      <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0" />
                      <span>
                        <b>Paused by the forecast.</b> There is no projected surplus this month, so no honest completion date
                        exists. Cut a category above or add income.
                      </span>
                    </div>
                  ) : (
                    <>
                      <div className="rounded-xl border border-teal-200 bg-teal-50/70 px-3 py-3">
                        <p className="flex items-center gap-1.5 text-xs font-medium text-teal-800">
                          <CalendarCheck2 className="h-3.5 w-3.5" /> Forecast-based completion
                        </p>
                        <p className="mt-1 text-xl font-bold tabular-nums text-teal-900">
                          {p.completionDate ? formatDateLabel(p.completionDate) : '—'}
                          <span className="ml-2 text-xs font-medium text-teal-700">
                            {p.monthsNeeded} month{p.monthsNeeded === 1 ? '' : 's'}
                          </span>
                        </p>
                        <p className="mt-0.5 text-[11px] leading-relaxed text-teal-800/80">
                          at {formatBDT(p.effectiveContributionPaisa)}/month
                          {p.scaledDown && (
                            <> — scaled down from your planned {formatBDT(p.plannedContributionPaisa)} to match the forecast surplus</>
                          )}
                        </p>
                        {p.naiveDate && p.monthsEarlierIfNaive != null && p.monthsEarlierIfNaive > 0 && (
                          <p className="mt-1.5 border-t border-teal-200/70 pt-1.5 text-[11px] text-stone-500">
                            Naive target ÷ contribution would claim{' '}
                            <span className="line-through">{formatDateLabel(p.naiveDate)}</span> ({p.naiveMonths} months) —{' '}
                            <b className="text-amber-700">{p.monthsEarlierIfNaive} months too optimistic</b>.
                          </p>
                        )}
                      </div>

                      {scenarioDelta && (
                        <p className="rounded-lg bg-amber-50 px-3 py-1.5 text-[11px] text-amber-800">
                          Scenario: what-if moved this date vs the base forecast
                          {p.completionDate && base?.completionDate && p.completionDate > base.completionDate ? ' (later)' : ' (earlier)'}.
                        </p>
                      )}

                      {p.dps && (
                        <div className="rounded-xl bg-stone-50 px-3 py-2.5 text-xs">
                          <p className="flex items-center gap-1.5 font-medium text-stone-700">
                            <Landmark className="h-3.5 w-3.5 text-stone-500" /> If this plan were a bank DPS
                          </p>
                          <p className="mt-1.5 tabular-nums leading-relaxed text-stone-600">
                            Depositing {formatBDT(p.dps.monthlyPaisa)}/month for {p.dps.months} months at{' '}
                            <b>{p.dps.ratePct}% p.a.</b> returns{' '}
                            <b className="text-stone-900">{formatBDT(p.dps.maturityPaisa)}</b> — your{' '}
                            {formatBDT(p.dps.depositedPaisa)} plus <b className="text-emerald-700">{formatBDT(p.dps.interestPaisa)}</b>{' '}
                            interest.
                          </p>
                          <p className="mt-1 text-[10px] leading-relaxed text-stone-400">
                            Method: {DPS_METHOD}. Rate is editable per pocket.
                          </p>
                        </div>
                      )}
                    </>
                  )}

                  {/* Contribution editor */}
                  <div className="mt-auto flex items-end gap-2 border-t border-stone-100 pt-3">
                    <div className="flex-1">
                      <Label htmlFor={`contrib-${p.pocket.id}`} className="text-[11px] text-stone-400">
                        Monthly contribution (৳)
                      </Label>
                      <Input
                        id={`contrib-${p.pocket.id}`}
                        type="number"
                        min="1"
                        placeholder={String(p.pocket.monthlyContributionPaisa / 100)}
                        value={editContrib[p.pocket.id] ?? ''}
                        onChange={e => setEditContrib(s => ({ ...s, [p.pocket.id]: e.target.value }))}
                        className="h-8 tabular-nums"
                      />
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-8"
                      disabled={busyId === p.pocket.id || !(editContrib[p.pocket.id] ?? '').length}
                      onClick={() => saveContribution(p)}
                    >
                      {busyId === p.pocket.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Pencil className="h-3.5 w-3.5" />}
                      Update
                    </Button>
                    <div className="flex-1">
                      <Label htmlFor={`dep-${p.pocket.id}`} className="text-[11px] text-stone-400">
                        Add deposit (৳)
                      </Label>
                      <Input
                        id={`dep-${p.pocket.id}`}
                        type="number"
                        min="1"
                        placeholder="500"
                        value={deposit[p.pocket.id] ?? ''}
                        onChange={e => setDeposit(s => ({ ...s, [p.pocket.id]: e.target.value }))}
                        className="h-8 tabular-nums"
                      />
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-8"
                      disabled={busyId === p.pocket.id || !(deposit[p.pocket.id] ?? '').length}
                      onClick={() => addDeposit(p)}
                    >
                      +
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* DPS explainer */}
      <Card className="rounded-2xl border-stone-200/80 bg-stone-50/60 shadow-sm">
        <CardContent className="flex flex-col gap-1 p-4 text-xs leading-relaxed text-stone-500 sm:flex-row sm:items-center sm:gap-4">
          <span className="shrink-0 font-semibold text-stone-700">How pocket dates & DPS are computed</span>
          <span>
            Completion date = today + ⌈remaining ÷ forecast-adjusted contribution⌉, where the adjustment comes from{' '}
            <b>salary − projected month-end spend</b>. DPS maturity uses {DPS_METHOD}. Everything is deterministic — no AI in
            the math.
          </span>
        </CardContent>
      </Card>
    </div>
  );
}
