'use client';

import { useMemo, useState } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
} from 'recharts';
import {
  TrendingDown,
  TrendingUp,
  Wallet,
  CalendarClock,
  PiggyBank,
  Lightbulb,
  Receipt,
  Repeat2,
  AlertTriangle,
  CircleAlert,
} from 'lucide-react';
import {
  formatBDT,
  formatDateLabel,
  type ExpenseRow,
  type Insight,
  type MonthSummary,
} from '@/lib/engine';

const PALETTE = ['#0f766e', '#0d9488', '#b45309', '#57534e', '#dc2626', '#4d7c0f', '#a16207', '#0e7490', '#9f1239'];

function StatCard({
  icon,
  label,
  value,
  valueClass,
  sub,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  valueClass?: string;
  sub: React.ReactNode;
}) {
  return (
    <Card className="rounded-2xl border-stone-200/80 shadow-sm">
      <CardContent className="p-5">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-stone-500">{label}</span>
          <span className="text-stone-400">{icon}</span>
        </div>
        <div className={`mt-2 text-2xl font-bold tracking-tight tabular-nums ${valueClass ?? ''}`}>{value}</div>
        <div className="mt-1 text-xs text-stone-500">{sub}</div>
      </CardContent>
    </Card>
  );
}

function InsightRow({ insight }: { insight: Insight }) {
  const tone = {
    danger: 'border-rose-200 bg-rose-50 text-rose-900',
    warning: 'border-amber-200 bg-amber-50 text-amber-900',
    positive: 'border-emerald-200 bg-emerald-50 text-emerald-900',
    info: 'border-stone-200 bg-stone-50 text-stone-800',
  }[insight.tone];
  const Icon =
    insight.tone === 'danger' ? CircleAlert : insight.tone === 'warning' ? AlertTriangle : insight.tone === 'positive' ? PiggyBank : Lightbulb;
  return (
    <div className={`flex items-start gap-2.5 rounded-xl border p-3 text-sm leading-relaxed ${tone}`}>
      <Icon className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
      <span>{insight.text}</span>
    </div>
  );
}

export function DashboardView({
  summary,
  salaryPaisa,
  expenses,
  insights,
  onDeleteExpense,
}: {
  summary: MonthSummary;
  salaryPaisa: number;
  expenses: ExpenseRow[];
  insights: Insight[];
  onDeleteExpense: (id: number) => void;
}) {
  const donutData = summary.byCategory.map((c, i) => ({
    name: c.category,
    value: c.totalPaisa / 100,
    fill: PALETTE[i % PALETTE.length],
    paisa: c.totalPaisa,
  }));
  const spentPct = salaryPaisa > 0 ? Math.min(100, (summary.spentSoFarPaisa / salaryPaisa) * 100) : 0;
  const topCategories = summary.byCategory.slice(0, 6);
  const maxCat = topCategories[0]?.totalPaisa || 1;
  const maxLast = Math.max(...topCategories.map(c => c.lastMonthPaisa), 1);

  return (
    <div className="space-y-5">
      {/* Stat row */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          icon={<Wallet className="h-4 w-4" />}
          label="Spent so far"
          value={formatBDT(summary.spentSoFarPaisa)}
          sub={
            salaryPaisa > 0 ? (
              <span>
                {Math.round(spentPct)}% of {formatBDT(salaryPaisa)} salary · {summary.expenseCount} expenses
              </span>
            ) : (
              <span>{summary.expenseCount} expenses · set your salary in the header</span>
            )
          }
        />
        <div className="sm:col-span-2 xl:col-span-1">
          <StatCard
            icon={<CalendarClock className="h-4 w-4" />}
            label="Projected month-end spend"
            value={formatBDT(summary.projectedSpendPaisa)}
            sub={`${formatBDT(summary.dailyBurnPaisa)}/day pace · ${summary.daysLeft} day${summary.daysLeft === 1 ? '' : 's'} left`}
          />
        </div>
        <StatCard
          icon={<PiggyBank className="h-4 w-4" />}
          label={summary.projectedLeftoverPaisa >= 0 ? 'Projected leftover' : 'Projected shortfall'}
          value={formatBDT(summary.projectedLeftoverPaisa)}
          valueClass={summary.projectedLeftoverPaisa >= 0 ? 'text-emerald-700' : 'text-rose-700'}
          sub={
            salaryPaisa > 0 ? (
              <span>after {formatBDT(salaryPaisa)} salary at month end</span>
            ) : (
              <span>set a salary to see the forecast</span>
            )
          }
        />
        <StatCard
          icon={summary.deltaVsLastMonthPaisa <= 0 ? <TrendingDown className="h-4 w-4" /> : <TrendingUp className="h-4 w-4" />}
          label="vs last month"
          value={
            summary.deltaPct == null
              ? '—'
              : `${summary.deltaVsLastMonthPaisa <= 0 ? '−' : '+'}${Math.abs(Math.round(summary.deltaPct))}%`
          }
          valueClass={summary.deltaVsLastMonthPaisa <= 0 ? 'text-emerald-700' : 'text-amber-700'}
          sub={`last month: ${formatBDT(summary.lastMonthSpentPaisa)} (${summary.deltaVsLastMonthPaisa <= 0 ? '−' : '+'}${formatBDT(Math.abs(summary.deltaVsLastMonthPaisa))})`}
        />
      </div>

      <div className="grid grid-cols-1 gap-5 xl:grid-cols-12">
        {/* Category breakdown */}
        <Card className="rounded-2xl border-stone-200/80 shadow-sm xl:col-span-7">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Where the money goes — {summary.monthLabel}</CardTitle>
            <CardDescription>Category breakdown of spending so far</CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-1 items-center gap-4 md:grid-cols-2">
            <div className="relative mx-auto h-[240px] w-full max-w-[260px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={donutData}
                    dataKey="value"
                    nameKey="name"
                    innerRadius={62}
                    outerRadius={95}
                    paddingAngle={2}
                    strokeWidth={0}
                  >
                    {donutData.map((entry, i) => (
                      <Cell key={entry.name} fill={PALETTE[i % PALETTE.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value, name) => [formatBDT(Math.round(Number(value) * 100)), name]}
                    contentStyle={{ borderRadius: 12, border: '1px solid #e7e5e4', fontSize: 13 }}
                  />
                </PieChart>
              </ResponsiveContainer>
              <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-[11px] uppercase tracking-wide text-stone-400">Total</span>
                <span className="text-lg font-bold tabular-nums text-stone-800">{formatBDT(summary.spentSoFarPaisa)}</span>
              </div>
            </div>
            <ScrollArea className="max-h-60 pr-2">
              <ul className="space-y-2">
                {summary.byCategory.map((c, i) => {
                  const pct = summary.spentSoFarPaisa > 0 ? Math.round((c.totalPaisa / summary.spentSoFarPaisa) * 100) : 0;
                  return (
                    <li key={c.category} className="flex items-center gap-2 text-sm">
                      <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: PALETTE[i % PALETTE.length] }} />
                      <span className="w-28 shrink-0 truncate text-stone-700">{c.category}</span>
                      <span className="flex-1"><Progress value={pct} className="h-2 bg-stone-100" /></span>
                      <span className="w-24 shrink-0 text-right font-medium tabular-nums text-stone-800">{formatBDT(c.totalPaisa)}</span>
                      <span className="w-10 shrink-0 text-right text-xs tabular-nums text-stone-400">{pct}%</span>
                    </li>
                  );
                })}
              </ul>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Forecast + insights */}
        <div className="space-y-5 xl:col-span-5">
          <Card className="rounded-2xl border-stone-200/80 shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Rest-of-month forecast</CardTitle>
              <CardDescription>Deterministic run-rate method — recomputed on every change</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex items-center justify-between rounded-lg bg-stone-50 px-3 py-2">
                <span className="text-stone-600">Spent so far</span>
                <span className="font-semibold tabular-nums">{formatBDT(summary.spentSoFarPaisa)}</span>
              </div>
              <div className="flex items-center justify-between rounded-lg bg-stone-50 px-3 py-2">
                <span className="text-stone-600">
                  + {formatBDT(summary.dailyBurnPaisa)}/day × {summary.daysLeft} day{summary.daysLeft === 1 ? '' : 's'} left
                </span>
                <span className="font-semibold tabular-nums">{formatBDT(summary.dailyBurnPaisa * summary.daysLeft)}</span>
              </div>
              <div className="flex items-center justify-between rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2">
                <span className="font-medium text-emerald-900">Projected month-end spend</span>
                <span className="font-bold tabular-nums text-emerald-900">{formatBDT(summary.projectedSpendPaisa)}</span>
              </div>
              <div
                className={`flex items-center justify-between rounded-lg px-3 py-2 ${
                  summary.projectedLeftoverPaisa >= 0 ? 'bg-stone-50' : 'border border-rose-200 bg-rose-50'
                }`}
              >
                <span className={summary.projectedLeftoverPaisa >= 0 ? 'text-stone-600' : 'font-medium text-rose-900'}>
                  {summary.projectedLeftoverPaisa >= 0 ? 'Expected money left at month end' : 'Expected shortfall at month end'}
                </span>
                <span
                  className={`font-bold tabular-nums ${summary.projectedLeftoverPaisa >= 0 ? 'text-stone-900' : 'text-rose-900'}`}
                >
                  {formatBDT(summary.projectedLeftoverPaisa)}
                </span>
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-2xl border-stone-200/80 shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-base">
                <Lightbulb className="h-4 w-4 text-amber-500" /> Insights
                <Badge variant="outline" className="ml-auto font-normal text-stone-500">live · updates with data</Badge>
              </CardTitle>
              <CardDescription>Generated from your real numbers — change one expense and watch them move</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2.5">
              {insights.map(i => (
                <InsightRow key={i.id} insight={i} />
              ))}
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-5 xl:grid-cols-12">
        {/* Largest + vs last month */}
        <Card className="rounded-2xl border-stone-200/80 shadow-sm xl:col-span-5">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Largest expenses this month</CardTitle>
          </CardHeader>
          <CardContent>
            {summary.largest.length === 0 ? (
              <p className="py-6 text-center text-sm text-stone-400">No expenses yet this month.</p>
            ) : (
              <ul className="divide-y divide-stone-100">
                {summary.largest.map((e, i) => (
                  <li key={e.id} className="flex items-center gap-3 py-2.5">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-stone-100 text-xs font-bold text-stone-500">
                      {i + 1}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-stone-800">{e.shop}</p>
                      <p className="text-xs text-stone-400">
                        {e.category} · {formatDateLabel(e.date)}
                      </p>
                    </div>
                    <span className="text-sm font-bold tabular-nums">{formatBDT(e.amountPaisa)}</span>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>

        <Card className="rounded-2xl border-stone-200/80 shadow-sm xl:col-span-7">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">This month vs last month</CardTitle>
            <CardDescription>Top categories, side by side</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {topCategories.length === 0 && <p className="py-6 text-center text-sm text-stone-400">No data yet.</p>}
            {topCategories.map((c, i) => (
              <div key={c.category}>
                <div className="mb-1 flex items-center justify-between text-xs">
                  <span className="font-medium text-stone-700">{c.category}</span>
                  <span className="tabular-nums text-stone-500">
                    {formatBDT(c.totalPaisa)} vs {formatBDT(c.lastMonthPaisa)}
                  </span>
                </div>
                <div className="space-y-1">
                  <div className="h-2 w-full rounded-full bg-stone-100">
                    <div
                      className="h-2 rounded-full transition-all"
                      style={{ width: `${(c.totalPaisa / maxCat) * 100}%`, background: PALETTE[i % PALETTE.length] }}
                    />
                  </div>
                  <div className="h-2 w-full rounded-full bg-stone-100">
                    <div
                      className="h-2 rounded-full bg-stone-300 transition-all"
                      style={{ width: `${(c.lastMonthPaisa / maxLast) * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
            <div className="flex items-center gap-4 pt-1 text-xs text-stone-400">
              <span className="flex items-center gap-1.5"><span className="h-2 w-4 rounded-full bg-teal-700" /> this month (so far)</span>
              <span className="flex items-center gap-1.5"><span className="h-2 w-4 rounded-full bg-stone-300" /> last month</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* All expenses */}
      <Card className="rounded-2xl border-stone-200/80 shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-base">
            <Receipt className="h-4 w-4 text-stone-400" /> All expenses
            {summary.recurring.length > 0 && (
              <Badge variant="outline" className="gap-1 border-teal-200 bg-teal-50 font-normal text-teal-800">
                <Repeat2 className="h-3 w-3" /> {summary.recurring.length} recurring detected
              </Badge>
            )}
          </CardTitle>
          <CardDescription>Receipt-sourced entries keep their OCR confidence score</CardDescription>
        </CardHeader>
        <CardContent>
          {expenses.length === 0 ? (
            <p className="py-8 text-center text-sm text-stone-400">
              Nothing recorded yet — add an expense manually or upload a receipt.
            </p>
          ) : (
            <div className="max-h-96 overflow-y-auto rounded-xl border border-stone-100">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-stone-50 text-left text-xs uppercase tracking-wide text-stone-400">
                  <tr>
                    <th className="px-4 py-2.5 font-medium">Date</th>
                    <th className="px-4 py-2.5 font-medium">Shop</th>
                    <th className="px-4 py-2.5 font-medium">Category</th>
                    <th className="px-4 py-2.5 text-right font-medium">Amount</th>
                    <th className="px-4 py-2.5 font-medium">Source</th>
                    <th className="px-4 py-2.5" />
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {expenses.map(e => (
                    <tr key={e.id} className="hover:bg-stone-50/60">
                      <td className="whitespace-nowrap px-4 py-2 tabular-nums text-stone-600">{formatDateLabel(e.date)}</td>
                      <td className="px-4 py-2 font-medium text-stone-800">{e.shop}</td>
                      <td className="px-4 py-2">
                        <Badge variant="outline" className="font-normal text-stone-500">{e.category}</Badge>
                      </td>
                      <td className="px-4 py-2 text-right font-semibold tabular-nums">{formatBDT(e.amountPaisa)}</td>
                      <td className="px-4 py-2">
                        {e.source === 'receipt' ? (
                          <Badge variant="outline" className="gap-1 border-teal-200 bg-teal-50 font-normal text-teal-800">
                            <Receipt className="h-3 w-3" /> OCR {Math.round((e.confidence ?? 0) * 100)}%
                          </Badge>
                        ) : (
                          <span className="text-xs text-stone-400">manual</span>
                        )}
                      </td>
                      <td className="px-2 py-2 text-right">
                        <button
                          onClick={() => onDeleteExpense(e.id)}
                          className="rounded-md px-2 py-1 text-xs text-stone-400 transition hover:bg-rose-50 hover:text-rose-600"
                          aria-label={`Delete expense at ${e.shop}`}
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
