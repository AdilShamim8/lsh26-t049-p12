'use client';

import { useRef, useState } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { toast } from '@/hooks/use-toast';
import {
  Upload,
  Loader2,
  ScanLine,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  ChevronDown,
  ImageIcon,
  PencilLine,
} from 'lucide-react';

export const CATEGORIES = [
  'Groceries',
  'Dining',
  'Transport',
  'Rent',
  'Utilities',
  'Mobile',
  'Shopping',
  'Health',
  'Entertainment',
  'Other',
];

const SAMPLES = [
  { file: '/samples/receipt-grocery.png', label: 'Grocery bill', hint: 'Meena Bazar · ৳1,809' },
  { file: '/samples/receipt-cafe.png', label: 'Restaurant bill', hint: 'Star Kabab · ৳1,881' },
  { file: '/samples/receipt-recharge.png', label: 'Mobile recharge', hint: 'bKash · ৳500' },
];

interface OcrFieldDto {
  value: string | null;
  confidence: number;
  uncertain: boolean;
  reason: string;
}
interface OcrResponseDto {
  ok: boolean;
  fields?: { shop: OcrFieldDto; amount: OcrFieldDto; date: OcrFieldDto };
  lines?: { index: number; text: string; conf: number }[];
  engine?: string;
  error?: string;
}

function ConfidenceBadge({ field }: { field: OcrFieldDto }) {
  if (field.value == null) {
    return (
      <Badge variant="outline" className="gap-1 border-rose-200 bg-rose-50 text-rose-700">
        <XCircle className="h-3 w-3" /> Not recognized
      </Badge>
    );
  }
  const pct = Math.round(field.confidence * 100);
  if (field.uncertain) {
    return (
      <Badge variant="outline" className="gap-1 border-amber-300 bg-amber-50 text-amber-800">
        <AlertTriangle className="h-3 w-3" /> {pct}% — verify
      </Badge>
    );
  }
  return (
    <Badge variant="outline" className="gap-1 border-emerald-200 bg-emerald-50 text-emerald-700">
      <CheckCircle2 className="h-3 w-3" /> {pct}% confident
    </Badge>
  );
}

export function AddExpenseView({ onSaved }: { onSaved: () => void }) {
  const today = new Date().toISOString().slice(0, 10);

  // Manual form
  const [mAmount, setMAmount] = useState('');
  const [mDate, setMDate] = useState(today);
  const [mShop, setMShop] = useState('');
  const [mCategory, setMCategory] = useState('');
  const [mBusy, setMBusy] = useState(false);

  // Receipt flow
  const fileRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [scanning, setScanning] = useState(false);
  const [ocr, setOcr] = useState<OcrResponseDto | null>(null);
  const [rShop, setRShop] = useState('');
  const [rAmount, setRAmount] = useState('');
  const [rDate, setRDate] = useState(today);
  const [rCategory, setRCategory] = useState('');
  const [ocrRaw, setOcrRaw] = useState(false);
  const [saving, setSaving] = useState(false);

  const rAmountNum = Number.parseFloat(rAmount);
  const rValid = rShop.trim().length > 0 && Number.isFinite(rAmountNum) && rAmountNum > 0 && !!rDate && !!rCategory;
  const avgConf =
    ocr?.fields
      ? (ocr.fields.shop.confidence + ocr.fields.amount.confidence + ocr.fields.date.confidence) / 3
      : null;

  async function submitManual(e: React.FormEvent) {
    e.preventDefault();
    const amount = Number.parseFloat(mAmount);
    if (!Number.isFinite(amount) || amount <= 0) {
      toast({ title: 'Enter a valid amount', variant: 'destructive' });
      return;
    }
    if (!mShop.trim() || !mCategory) {
      toast({ title: 'Shop and category are required', variant: 'destructive' });
      return;
    }
    setMBusy(true);
    try {
      const res = await fetch('/api/expenses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          date: mDate,
          shop: mShop.trim(),
          category: mCategory,
          amountPaisa: Math.round(amount * 100),
          source: 'manual',
        }),
      });
      if (!res.ok) throw new Error((await res.json()).error ?? 'Failed');
      toast({ title: 'Expense saved', description: 'Dashboard, forecast and insights updated instantly.' });
      setMAmount('');
      setMShop('');
      onSaved();
    } catch (err) {
      toast({ title: 'Could not save', description: err instanceof Error ? err.message : 'Try again', variant: 'destructive' });
    } finally {
      setMBusy(false);
    }
  }

  async function runOcr(dataUrl: string) {
    setScanning(true);
    setOcr(null);
    try {
      const res = await fetch('/api/ocr', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageBase64: dataUrl }),
      });
      const dto: OcrResponseDto = await res.json();
      if (!res.ok || !dto.ok || !dto.fields) {
        throw new Error(dto.error ?? 'OCR failed');
      }
      setOcr(dto);
      setRShop(dto.fields.shop.value ?? '');
      setRAmount(dto.fields.amount.value ?? '');
      setRDate(dto.fields.date.value ?? today);
      setRCategory('');
      const missing = [dto.fields.shop, dto.fields.amount, dto.fields.date].filter(f => f.value == null).length;
      toast({
        title: missing === 0 ? 'Receipt read successfully' : `Receipt read — ${missing} field${missing > 1 ? 's' : ''} need your attention`,
        description: 'Review every field below before saving.',
        variant: missing === 0 ? 'default' : 'destructive',
      });
    } catch (err) {
      toast({
        title: 'OCR unavailable',
        description: err instanceof Error ? err.message : 'You can still add the expense manually.',
        variant: 'destructive',
      });
    } finally {
      setScanning(false);
    }
  }

  async function runSample(path: string) {
    setPreview(path);
    try {
      const res = await fetch(path);
      const blob = await res.blob();
      const reader = new FileReader();
      reader.onload = () => runOcr(String(reader.result));
      reader.readAsDataURL(blob);
    } catch {
      toast({ title: 'Could not load the sample receipt', variant: 'destructive' });
    }
  }

  function handleFile(file: File) {
    if (!file.type.startsWith('image/')) {
      toast({ title: 'Please choose an image file', variant: 'destructive' });
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result);
      setPreview(dataUrl);
      runOcr(dataUrl);
    };
    reader.readAsDataURL(file);
  }

  async function saveReceiptExpense() {
    if (!rValid) return;
    setSaving(true);
    try {
      const res = await fetch('/api/expenses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          date: rDate,
          shop: rShop.trim(),
          category: rCategory,
          amountPaisa: Math.round(rAmountNum * 100),
          source: 'receipt',
          confidence: avgConf,
        }),
      });
      if (!res.ok) throw new Error((await res.json()).error ?? 'Failed');
      toast({ title: 'Receipt expense saved', description: 'Every forecast, insight and pocket date just recalculated.' });
      setPreview(null);
      setOcr(null);
      setRShop('');
      setRAmount('');
      setRDate(today);
      setRCategory('');
      onSaved();
    } catch (err) {
      toast({ title: 'Could not save', description: err instanceof Error ? err.message : 'Try again', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  }

  const uncertainCount = ocr?.fields
    ? [ocr.fields.shop, ocr.fields.amount, ocr.fields.date].filter(f => f.value == null || f.uncertain).length
    : 0;

  return (
    <div className="grid grid-cols-1 gap-5 xl:grid-cols-2">
      {/* Manual entry */}
      <Card className="rounded-2xl border-stone-200/80 shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <PencilLine className="h-4 w-4 text-stone-400" /> Manual expense
          </CardTitle>
          <CardDescription>Fastest path when you already know the amount</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={submitManual} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="m-amount">Amount (৳)</Label>
                <Input
                  id="m-amount"
                  type="number"
                  min="0.01"
                  step="0.01"
                  placeholder="450"
                  value={mAmount}
                  onChange={e => setMAmount(e.target.value)}
                  className="tabular-nums"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="m-date">Date</Label>
                <Input id="m-date" type="date" value={mDate} onChange={e => setMDate(e.target.value)} />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="m-shop">Shop</Label>
              <Input id="m-shop" placeholder="e.g. Meena Bazar" value={mShop} onChange={e => setMShop(e.target.value)} maxLength={120} />
            </div>
            <div className="space-y-1.5">
              <Label>Category</Label>
              <Select value={mCategory} onValueChange={setMCategory}>
                <SelectTrigger aria-label="Category">
                  <SelectValue placeholder="Choose a category" />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map(c => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button type="submit" disabled={mBusy} className="w-full bg-teal-700 hover:bg-teal-800">
              {mBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Save expense'}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Receipt upload + review */}
      <Card className="rounded-2xl border-stone-200/80 shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <ScanLine className="h-4 w-4 text-teal-700" /> Upload a bill or receipt
          </CardTitle>
          <CardDescription>
            On-device OCR reads amount, date and shop — nothing is invented; you confirm every field
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={e => {
              const f = e.target.files?.[0];
              if (f) handleFile(f);
              e.target.value = '';
            }}
          />
          <div
            role="button"
            tabIndex={0}
            aria-label="Upload receipt image"
            onClick={() => fileRef.current?.click()}
            onKeyDown={e => e.key === 'Enter' && fileRef.current?.click()}
            onDragOver={e => e.preventDefault()}
            onDrop={e => {
              e.preventDefault();
              const f = e.dataTransfer.files?.[0];
              if (f) handleFile(f);
            }}
            className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-stone-300 bg-stone-50/60 px-4 py-8 text-center transition hover:border-teal-400 hover:bg-teal-50/40"
          >
            {scanning ? (
              <>
                <Loader2 className="h-7 w-7 animate-spin text-teal-700" />
                <p className="text-sm font-medium text-teal-800">Reading the receipt…</p>
                <p className="text-xs text-stone-400">Running on-device OCR with word confidence</p>
              </>
            ) : (
              <>
                <Upload className="h-7 w-7 text-stone-400" />
                <p className="text-sm font-medium text-stone-700">Click or drop a receipt photo</p>
                <p className="text-xs text-stone-400">PNG / JPG · works best on clear printed bills</p>
              </>
            )}
          </div>

          <div>
            <p className="mb-2 text-xs font-medium uppercase tracking-wide text-stone-400">No receipt handy? Try a sample:</p>
            <div className="grid grid-cols-3 gap-2">
              {SAMPLES.map(s => (
                <button
                  key={s.file}
                  onClick={() => runSample(s.file)}
                  disabled={scanning}
                  className="group overflow-hidden rounded-xl border border-stone-200 bg-white text-left transition hover:border-teal-400 hover:shadow-sm disabled:opacity-50"
                >
                  { }
                  <img src={s.file} alt={`${s.label} sample`} className="h-16 w-full object-cover object-top" />
                  <span className="block px-2 py-1.5 text-[11px] leading-tight">
                    <span className="block font-medium text-stone-700">{s.label}</span>
                    <span className="text-stone-400">{s.hint}</span>
                  </span>
                </button>
              ))}
            </div>
          </div>

          {preview && (
            <div className="rounded-xl border border-stone-200 p-3">
              <div className="flex gap-3">
                { }
                <img src={preview} alt="Receipt preview" className="h-24 w-20 shrink-0 rounded-lg border border-stone-100 object-cover" />
                <div className="min-w-0 flex-1 text-xs text-stone-500">
                  <p className="flex items-center gap-1 font-medium text-stone-700">
                    <ImageIcon className="h-3.5 w-3.5" /> {ocr ? `Parsed by ${ocr.engine}` : 'Image ready'}
                  </p>
                  <p className="mt-1">
                    Check each field against the image. Amber badges mean low OCR confidence; red means the field could not
                    be read and must be filled by you.
                  </p>
                </div>
              </div>

              {ocr?.fields && (
                <div className="mt-3 space-y-3">
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="r-shop">Shop</Label>
                      <ConfidenceBadge field={ocr.fields.shop} />
                    </div>
                    <Input id="r-shop" value={rShop} onChange={e => setRShop(e.target.value)} maxLength={120} />
                    <p className="text-[11px] text-stone-400">{ocr.fields.shop.reason}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="r-amount">Amount (৳)</Label>
                        <ConfidenceBadge field={ocr.fields.amount} />
                      </div>
                      <Input
                        id="r-amount"
                        type="number"
                        min="0.01"
                        step="0.01"
                        value={rAmount}
                        onChange={e => setRAmount(e.target.value)}
                        className="tabular-nums"
                      />
                      <p className="text-[11px] text-stone-400">{ocr.fields.amount.reason}</p>
                    </div>
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="r-date">Date</Label>
                        <ConfidenceBadge field={ocr.fields.date} />
                      </div>
                      <Input id="r-date" type="date" value={rDate} onChange={e => setRDate(e.target.value)} />
                      <p className="text-[11px] text-stone-400">{ocr.fields.date.reason}</p>
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Category</Label>
                    <Select value={rCategory} onValueChange={setRCategory}>
                      <SelectTrigger aria-label="Receipt category">
                        <SelectValue placeholder="Choose a category" />
                      </SelectTrigger>
                      <SelectContent>
                        {CATEGORIES.map(c => (
                          <SelectItem key={c} value={c}>{c}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {uncertainCount > 0 && (
                    <p className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
                      {uncertainCount} field{uncertainCount > 1 ? 's' : ''} flagged for review — correct them before saving.
                      The app will not guess values for you.
                    </p>
                  )}

                  <Button onClick={saveReceiptExpense} disabled={!rValid || saving} className="w-full bg-teal-700 hover:bg-teal-800">
                    {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Save receipt expense'}
                  </Button>

                  {ocr.lines && ocr.lines.length > 0 && (
                    <Collapsible open={ocrRaw} onOpenChange={setOcrRaw}>
                      <CollapsibleTrigger className="flex w-full items-center justify-center gap-1 rounded-lg py-1.5 text-xs text-stone-500 hover:bg-stone-50">
                        What the OCR saw <ChevronDown className={`h-3.5 w-3.5 transition ${ocrRaw ? 'rotate-180' : ''}`} />
                      </CollapsibleTrigger>
                      <CollapsibleContent>
                        <div className="max-h-44 overflow-y-auto rounded-lg bg-stone-950 p-3 font-mono text-[11px] leading-relaxed text-stone-300">
                          {ocr.lines.map(l => (
                            <div key={l.index} className="flex justify-between gap-3">
                              <span className="truncate">{l.text}</span>
                              <span className={l.conf < 65 ? 'text-amber-400' : 'text-emerald-500'}>{Math.round(l.conf)}%</span>
                            </div>
                          ))}
                        </div>
                      </CollapsibleContent>
                    </Collapsible>
                  )}
                </div>
              )}
            </div>
          )}

          <p className="text-[11px] leading-relaxed text-stone-400">
            Privacy: images are processed on the server for OCR and never stored. Saving keeps only the fields you confirmed.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
