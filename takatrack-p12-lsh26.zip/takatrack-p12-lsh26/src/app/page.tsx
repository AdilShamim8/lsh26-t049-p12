'use client';

import { useEffect, useMemo, useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { toast } from '@/hooks/use-toast';
import { DashboardView } from '@/components/dashboard-view';
import { AddExpenseView } from '@/components/add-expense-view';
import { PocketsView } from '@/components/pockets-view';
import {
  applyWhatIf,
  formatBDT,
  generateInsights,
  projectPockets,
  summarize,
  type ExpenseRow,
  type PocketRow,
} from '@/lib/engine';
import {
  Wallet,
  Database,
  RotateCcw,
  LayoutDashboard,
  PlusCircle,
  Target,
  Loader2,
  Map,
  Banknote,
} from 'lucide-react';

type Tab = 'dashboard' | 'add' | 'pockets';

interface AppState {
  salaryPaisa: number;
  expenses: ExpenseRow[];
  pockets: PocketRow[];
}

const TABS: { id: Tab; label: string; icon: React.ReactNode }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="h-4 w-4" /> },
  { id: 'add', label: 'Add Expense', icon: <PlusCircle className="h-4 w-4" /> },
  { id: 'pockets', label: 'Savings Pockets', icon: <Target className="h-4 w-4" /> },
];

export default function Home() {
  const [tab, setTab] = useState<Tab>('dashboard');
  const [state, setState] = useState<AppState | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [now] = useState(() => new Date());
  const [cuts, setCuts] = useState<Record<string, number>>({});
  const [whatifApplied, setWhatifApplied] = useState(true);

  // salary dialog
  const [salaryOpen, setSalaryOpen] = useState(false);
  const [salaryInput, setSalaryInput] = useState('');

  const refresh = async (): Promise<void> => {
    const res = await fetch('/api/state', { cache: 'no-store' });
    const dto: AppState = await res.json();
    setState(dto);
  };

  useEffect(() => {
    refresh();
  }, []);

  const salaryPaisa = state?.salaryPaisa ?? 0;
  const expenses = state?.expenses ?? [];
  const pockets = state?.pockets ?? [];

  const summary = useMemo(() => summarize(expenses, salaryPaisa, now), [expenses, salaryPaisa, now]);
  const insights = useMemo(() => generateInsights(summary, salaryPaisa, pockets), [summary, salaryPaisa, pockets]);
  const whatif = useMemo(() => applyWhatIf(summary, salaryPaisa, cuts), [summary, salaryPaisa, cuts]);
  const anyCut = Object.values(cuts).some(v => v > 0);
  const activeSurplus = whatifApplied && anyCut ? whatif.newSurplusPaisa : summary.projectedLeftoverPaisa;
  const projections = useMemo(() => projectPockets(pockets, activeSurplus, now), [pockets, activeSurplus, now]);
  const baseProjections = useMemo(() => projectPockets(pockets, summary.projectedLeftoverPaisa, now), [pockets, summary.projectedLeftoverPaisa, now]);

  async function saveSalary() {
    const taka = Number.parseFloat(salaryInput);
    if (!Number.isFinite(taka) || taka <= 0) {
      toast({ title: 'Enter a valid monthly salary', variant: 'destructive' });
      return;
    }
    setBusy('salary');
    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ monthlySalaryPaisa: Math.round(taka * 100) }),
      });
      if (!res.ok) throw new Error('Failed to save salary');
      await refresh();
      toast({ title: 'Monthly salary updated', description: 'Forecast, insights and pocket dates recalculated.' });
      setSalaryOpen(false);
    } catch (e) {
      toast({ title: 'Could not save salary', description: e instanceof Error ? e.message : undefined, variant: 'destructive' });
    } finally {
      setBusy(null);
    }
  }

  async function loadDemo() {
    setBusy('seed');
    try {
      const res = await fetch('/api/seed', { method: 'POST' });
      if (!res.ok) throw new Error('Failed to load demo data');
      await refresh();
      toast({ title: 'Demo data loaded', description: 'Two months of expenses, salary and three savings pockets.' });
    } catch (e) {
      toast({ title: 'Could not load demo data', description: e instanceof Error ? e.message : undefined, variant: 'destructive' });
    } finally {
      setBusy(null);
    }
  }

  async function resetAll() {
    setBusy('reset');
    try {
      const res = await fetch('/api/reset', { method: 'POST' });
      if (!res.ok) throw new Error('Failed to reset');
      setCuts({});
      await refresh();
      toast({ title: 'All data cleared', description: 'A fresh ledger is ready.' });
    } catch (e) {
      toast({ title: 'Could not reset', description: e instanceof Error ? e.message : undefined, variant: 'destructive' });
    } finally {
      setBusy(null);
    }
  }

  async function deleteExpense(id: number) {
    setState(s => (s ? { ...s, expenses: s.expenses.filter(e => e.id !== id) } : s));
    await fetch(`/api/expenses/${id}`, { method: 'DELETE' });
    await refresh();
    toast({ title: 'Expense deleted', description: 'Insights and forecast updated.' });
  }

  async function createPocket(data: {
    name: string;
    itemDetails: string;
    targetPaisa: number;
    monthlyContributionPaisa: number;
    savedPaisa: number;
    dpsRate: number;
  }) {
    const res = await fetch('/api/pockets', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      toast({ title: err.error ?? 'Could not create pocket', variant: 'destructive' });
      return;
    }
    await refresh();
  }

  async function patchPocket(id: number, data: Record<string, number | string>) {
    const res = await fetch(`/api/pockets/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      toast({ title: err.error ?? 'Could not update pocket', variant: 'destructive' });
      return;
    }
    await refresh();
  }

  async function deletePocket(id: number) {
    setState(s => (s ? { ...s, pockets: s.pockets.filter(p => p.id !== id) } : s));
    await fetch(`/api/pockets/${id}`, { method: 'DELETE' });
    await refresh();
  }

  return (
    <div className="flex min-h-screen flex-col bg-[#f6f5f1] text-stone-900">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-stone-200/80 bg-white/85 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-3 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-teal-700 text-white shadow-sm">
              <Wallet className="h-5 w-5" />
            </span>
            <div>
              <h1 className="text-base font-bold leading-tight tracking-tight">
                TakaTrack
                <Badge variant="outline" className="ml-2 border-teal-200 bg-teal-50 align-middle text-[10px] font-semibold text-teal-800">
                  P12
                </Badge>
              </h1>
              <p className="text-[11px] leading-tight text-stone-400">Personal Ledger Manager · LofiStack Hackathon 2026</p>
            </div>
          </div>

          <div className="ml-auto flex flex-wrap items-center gap-2">
            {/* Salary control */}
            <Dialog open={salaryOpen} onOpenChange={setSalaryOpen}>
              <DialogTrigger asChild>
                <button
                  className="group flex items-center gap-2 rounded-xl border border-stone-200 bg-white px-3 py-2 text-sm transition hover:border-teal-400"
                  aria-label="Set monthly salary"
                  onClick={() => {
                    setSalaryInput(salaryPaisa > 0 ? String(salaryPaisa / 100) : '');
                    setSalaryOpen(true);
                  }}
                >
                  <Banknote className="h-4 w-4 text-teal-700" />
                  <span className="font-semibold tabular-nums">
                    {salaryPaisa > 0 ? `${formatBDT(salaryPaisa)}/mo` : 'Set salary'}
                  </span>
                  <Pencil className="h-3 w-3 text-stone-300 transition group-hover:text-stone-500" />
                </button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-sm">
                <DialogHeader>
                  <DialogTitle>Monthly salary</DialogTitle>
                  <DialogDescription>The forecast, insights and every pocket date are derived from this number.</DialogDescription>
                </DialogHeader>
                <div className="space-y-1.5">
                  <Label htmlFor="salary">Amount (৳ per month)</Label>
                  <Input
                    id="salary"
                    type="number"
                    min="1"
                    step="1"
                    placeholder="45000"
                    value={salaryInput}
                    onChange={e => setSalaryInput(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && saveSalary()}
                    className="tabular-nums"
                  />
                </div>
                <DialogFooter>
                  <Button onClick={saveSalary} disabled={busy === 'salary'} className="w-full bg-teal-700 hover:bg-teal-800">
                    {busy === 'salary' ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Save salary'}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            <Button variant="outline" size="sm" className="h-9 border-stone-300" onClick={loadDemo} disabled={busy === 'seed'}>
              {busy === 'seed' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Database className="h-4 w-4" />}
              Load demo data
            </Button>
            <Button variant="ghost" size="sm" className="h-9 text-stone-500" onClick={resetAll} disabled={busy === 'reset'}>
              {busy === 'reset' ? <Loader2 className="h-4 w-4 animate-spin" /> : <RotateCcw className="h-4 w-4" />}
              Reset
            </Button>
          </div>
        </div>

        {/* Tabs */}
        <nav className="mx-auto max-w-7xl px-4 sm:px-6" aria-label="Sections">
          <div className="flex gap-1 pb-px">
            {TABS.map(t => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                aria-current={tab === t.id ? 'page' : undefined}
                className={`flex items-center gap-2 rounded-t-lg border-b-2 px-4 py-2.5 text-sm font-medium transition ${
                  tab === t.id
                    ? 'border-teal-700 text-teal-800'
                    : 'border-transparent text-stone-500 hover:text-stone-800'
                }`}
              >
                {t.icon}
                {t.label}
                {t.id === 'pockets' && pockets.length > 0 && (
                  <span className="rounded-full bg-stone-100 px-1.5 text-[11px] tabular-nums text-stone-500">{pockets.length}</span>
                )}
              </button>
            ))}
          </div>
        </nav>
      </header>

      {/* Body */}
      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-6 sm:px-6">
        {!state ? (
          <div className="flex items-center justify-center py-32 text-stone-400">
            <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Loading your ledger…
          </div>
        ) : expenses.length === 0 && pockets.length === 0 ? (
          <div className="mx-auto max-w-lg py-10 text-center">
            <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-teal-700/10 text-teal-800">
              <Wallet className="h-7 w-7" />
            </span>
            <h2 className="mt-4 text-xl font-bold">A clear view of your month starts here</h2>
            <p className="mt-2 text-sm leading-relaxed text-stone-500">
              Set your salary, add expenses manually or snap a receipt — TakaTrack reads it with on-device OCR, forecasts the
              rest of your month, and puts real dates on your savings goals.
            </p>
            <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
              <Button onClick={loadDemo} disabled={busy === 'seed'} className="bg-teal-700 hover:bg-teal-800">
                {busy === 'seed' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Database className="h-4 w-4" />}
                Load demo data
              </Button>
              <Button variant="outline" className="border-stone-300" onClick={() => setTab('add')}>
                <PlusCircle className="h-4 w-4" /> Add first expense
              </Button>
            </div>
            <p className="mt-4 text-xs text-stone-400">Demo data includes two months of expenses so comparisons work on day one.</p>
          </div>
        ) : tab === 'dashboard' ? (
          <DashboardView
            summary={summary}
            salaryPaisa={salaryPaisa}
            expenses={expenses}
            insights={insights}
            onDeleteExpense={deleteExpense}
          />
        ) : tab === 'add' ? (
          <AddExpenseView onSaved={refresh} />
        ) : (
          <PocketsView
            summary={summary}
            salaryPaisa={salaryPaisa}
            projections={projections}
            baseProjections={baseProjections}
            cuts={cuts}
            setCuts={setCuts}
            whatif={whatif}
            whatifApplied={whatifApplied}
            setWhatifApplied={setWhatifApplied}
            onCreatePocket={createPocket}
            onPatchPocket={patchPocket}
            onDeletePocket={deletePocket}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-stone-200/80 bg-white/70">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-x-4 gap-y-2 px-4 py-4 text-xs text-stone-500 sm:px-6">
          <span>
            <b className="text-stone-700">TakaTrack</b> — built by Team ReWoo for LofiStack Hackathon 2026 · Problem P12
          </span>
          <span className="hidden sm:inline">·</span>
          <span>Deterministic finance engine · Tesseract OCR · Next.js</span>
          <Popover>
            <PopoverTrigger asChild>
              <button className="ml-auto flex items-center gap-1.5 rounded-lg border border-stone-200 bg-white px-2.5 py-1.5 font-medium text-stone-600 transition hover:border-teal-400 hover:text-teal-800">
                <Map className="h-3.5 w-3.5" /> Requirement map
              </button>
            </PopoverTrigger>
            <PopoverContent align="end" className="w-96 text-sm">
              <p className="mb-2 font-semibold">Where each scored requirement lives</p>
              <ul className="space-y-2 text-xs leading-relaxed text-stone-600">
                <li>
                  <b className="text-stone-800">R1 — Receipt/image entry:</b> Add Expense tab → upload or pick a sample bill;
                  OCR shows amount/date/shop with confidence badges; nothing saves until you verify; uncertain fields must be
                  corrected by hand.
                </li>
                <li>
                  <b className="text-stone-800">R2 — Monthly dashboard:</b> Dashboard tab → spent vs salary, category
                  breakdown, largest expenses, and change vs last month.
                </li>
                <li>
                  <b className="text-stone-800">R3 — Forecast + insights:</b> Dashboard right column → run-rate forecast,
                  expected leftover/shortfall, and five insights computed from live numbers (delete an expense and watch them
                  change).
                </li>
                <li>
                  <b className="text-stone-800">R4 — Savings pockets:</b> Pockets tab → forecast-rationed completion dates
                  (never naive target ÷ contribution), DPS maturity at a stated rate and formula, plus bonuses: live
                  contribution edits, recurring-payment detection, and the what-if category sliders.
                </li>
              </ul>
            </PopoverContent>
          </Popover>
        </div>
      </footer>
    </div>
  );
}

function Pencil({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z" />
    </svg>
  );
}
