import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const numId = Number(id);
  if (!Number.isInteger(numId)) return NextResponse.json({ error: 'Invalid id' }, { status: 400 });
  const b = await req.json().catch(() => null);
  const data: Record<string, number | string> = {};

  if (b?.monthlyContributionPaisa != null) {
    const v = Number(b.monthlyContributionPaisa);
    if (!Number.isInteger(v) || v <= 0 || v > 1_000_000_000) return NextResponse.json({ error: 'Invalid contribution' }, { status: 400 });
    data.monthlyContributionPaisa = v;
  }
  if (b?.savedPaisa != null) {
    const v = Number(b.savedPaisa);
    if (!Number.isInteger(v) || v < 0 || v > 1_000_000_000) return NextResponse.json({ error: 'Invalid saved amount' }, { status: 400 });
    data.savedPaisa = v;
  }
  if (b?.dpsRate != null) {
    const v = Number(b.dpsRate);
    if (!Number.isFinite(v) || v < 0 || v > 100) return NextResponse.json({ error: 'Invalid DPS rate' }, { status: 400 });
    data.dpsRate = v;
  }
  if (b?.name != null) {
    const v = String(b.name).trim();
    if (!v || v.length > 80) return NextResponse.json({ error: 'Invalid name' }, { status: 400 });
    data.name = v;
  }
  if (Object.keys(data).length === 0) return NextResponse.json({ error: 'Nothing to update' }, { status: 400 });
  await db.pocket.update({ where: { id: numId }, data }).catch(() => null);
  return NextResponse.json({ ok: true });
}

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const numId = Number(id);
  if (!Number.isInteger(numId)) return NextResponse.json({ error: 'Invalid id' }, { status: 400 });
  await db.pocket.delete({ where: { id: numId } }).catch(() => null);
  return NextResponse.json({ ok: true });
}
