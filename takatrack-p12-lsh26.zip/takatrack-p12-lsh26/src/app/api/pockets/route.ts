import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(req: NextRequest) {
  const b = await req.json().catch(() => null);
  const name = typeof b?.name === 'string' ? b.name.trim() : '';
  const itemDetails = typeof b?.itemDetails === 'string' ? b.itemDetails.trim().slice(0, 200) : '';
  const targetPaisa = Number(b?.targetPaisa);
  const monthlyContributionPaisa = Number(b?.monthlyContributionPaisa);
  const savedPaisa = Number(b?.savedPaisa ?? 0);
  const dpsRate = Number(b?.dpsRate ?? 9.5);
  if (!name || name.length > 80) return NextResponse.json({ error: 'Pocket name is required' }, { status: 400 });
  if (!Number.isInteger(targetPaisa) || targetPaisa <= 0 || targetPaisa > 1_000_000_000) return NextResponse.json({ error: 'Target must be a positive number' }, { status: 400 });
  if (!Number.isInteger(monthlyContributionPaisa) || monthlyContributionPaisa <= 0 || monthlyContributionPaisa > 1_000_000_000) return NextResponse.json({ error: 'Monthly contribution must be a positive number' }, { status: 400 });
  if (!Number.isInteger(savedPaisa) || savedPaisa < 0) return NextResponse.json({ error: 'Saved amount must be zero or more' }, { status: 400 });
  if (!Number.isFinite(dpsRate) || dpsRate < 0 || dpsRate > 100) return NextResponse.json({ error: 'DPS rate must be between 0 and 100' }, { status: 400 });
  const created = await db.pocket.create({
    data: { name, itemDetails, targetPaisa, monthlyContributionPaisa, savedPaisa, dpsRate },
  });
  return NextResponse.json({ ok: true, id: created.id });
}
