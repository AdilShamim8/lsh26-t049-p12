import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

function parseBody(body: unknown) {
  const b = (body ?? {}) as Record<string, unknown>;
  const amountPaisa = Number(b.amountPaisa);
  const date = typeof b.date === 'string' ? b.date : '';
  const shop = typeof b.shop === 'string' ? b.shop.trim() : '';
  const category = typeof b.category === 'string' ? b.category.trim() : '';
  const source = b.source === 'receipt' ? 'receipt' : 'manual';
  const confidence = b.confidence == null ? null : Number(b.confidence);
  if (!Number.isInteger(amountPaisa) || amountPaisa <= 0 || amountPaisa > 1_000_000_000) return { error: 'Amount must be a positive number' } as const;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return { error: 'Invalid date' } as const;
  if (!shop || shop.length > 120) return { error: 'Shop name is required' } as const;
  if (!category || category.length > 60) return { error: 'Category is required' } as const;
  if (confidence != null && (!Number.isFinite(confidence) || confidence < 0 || confidence > 1)) return { error: 'Invalid confidence' } as const;
  return { amountPaisa, date, shop, category, source, confidence } as const;
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const parsed = parseBody(body);
  if ('error' in parsed) return NextResponse.json({ error: parsed.error }, { status: 400 });
  const created = await db.expense.create({
    data: {
      date: new Date(`${parsed.date}T12:00:00.000Z`),
      shop: parsed.shop,
      category: parsed.category,
      amountPaisa: parsed.amountPaisa,
      source: parsed.source,
      confidence: parsed.confidence,
    },
  });
  return NextResponse.json({ ok: true, id: created.id });
}
