import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function PUT(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const monthlySalary = Number(body?.monthlySalaryPaisa);
  if (!Number.isInteger(monthlySalary) || monthlySalary < 0 || monthlySalary > 1_000_000_000) {
    return NextResponse.json({ error: 'Invalid salary' }, { status: 400 });
  }
  await db.settings.upsert({
    where: { id: 1 },
    update: { monthlySalary },
    create: { id: 1, monthlySalary },
  });
  return NextResponse.json({ ok: true, salaryPaisa: monthlySalary });
}
