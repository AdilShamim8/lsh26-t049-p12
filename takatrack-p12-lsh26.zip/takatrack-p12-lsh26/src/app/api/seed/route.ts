import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';

// Deterministic demo dataset, generated relative to "now" so the demo always
// has a live current month AND a previous month for comparison/recurring logic.
function d(base: Date, day: number): Date {
  return new Date(Date.UTC(base.getUTCFullYear(), base.getUTCMonth(), day, 12, 0, 0));
}
function iso(dt: Date): string {
  return dt.toISOString().slice(0, 10);
}

export async function POST() {
  const now = new Date();
  const y = now.getUTCFullYear();
  const m = now.getUTCMonth();
  const prev = new Date(Date.UTC(y, m - 1, 1, 12));
  const daysThis = now.getUTCDate();
  const daysPrev = new Date(Date.UTC(y, m, 0)).getUTCDate();
  const dayThis = (day: number) => Math.min(day, daysThis);
  const today = iso(now);

  type Row = { date: string; shop: string; category: string; amountPaisa: number; source?: 'receipt'; confidence?: number };
  const rows: Row[] = [];

  // ---- Previous month (slightly heavier spending => positive vs-last-month story)
  const prevRows: [number, string, string, number][] = [
    [1, 'Dhaka House Rent', 'Rent', 1200000],
    [2, 'Link3 Internet', 'Utilities', 120000],
    [3, 'Meena Bazar', 'Groceries', 438000],
    [5, 'bKash Recharge', 'Mobile', 50000],
    [6, 'Uber', 'Transport', 32000],
    [7, 'Star Kabab', 'Dining', 145000],
    [9, 'Meena Bazar', 'Groceries', 262000],
    [10, 'Electricity Bill (DESCO)', 'Utilities', 236000],
    [11, 'Uber', 'Transport', 21000],
    [13, 'Aarong', 'Shopping', 420000],
    [14, 'bKash Recharge', 'Mobile', 50000],
    [15, 'Star Kabab', 'Dining', 89000],
    [17, 'Pathao Ride', 'Transport', 18000],
    [18, 'Lazz Pharma', 'Health', 65000],
    [19, 'Meena Bazar', 'Groceries', 305000],
    [21, 'Chillox', 'Dining', 98000],
    [22, 'Uber', 'Transport', 35000],
    [24, 'Link3 Internet', 'Utilities', 120000],
    [25, 'bKash Recharge', 'Mobile', 50000],
    [26, 'Cineplex', 'Entertainment', 80000],
    [27, 'Meena Bazar', 'Groceries', 198000],
    [28, 'Uber', 'Transport', 26000],
  ];
  for (const [day, shop, category, amountPaisa] of prevRows) {
    rows.push({ date: iso(d(prev, Math.min(day, daysPrev))), shop, category, amountPaisa });
  }
  rows.push({ date: iso(d(prev, 8)), shop: 'Gloria Jean\'s Coffee', category: 'Dining', amountPaisa: 76000 });

  // ---- Current month (day <= today)
  const thisRows: [number, string, string, number, ('receipt' | 'manual')?, number?][] = [
    [1, 'Dhaka House Rent', 'Rent', 1200000],
    [1, 'Link3 Internet', 'Utilities', 120000, 'receipt', 0.97],
    [2, 'Meena Bazar', 'Groceries', 412000],
    [3, 'bKash Recharge', 'Mobile', 50000],
    [4, 'Uber', 'Transport', 28000],
    [5, 'Star Kabab', 'Dining', 102000, 'receipt', 0.88],
    [6, 'Meena Bazar', 'Groceries', 185000],
    [7, 'Electricity Bill (DESCO)', 'Utilities', 224000],
    [8, 'Uber', 'Transport', 19500],
    [9, 'Lazz Pharma', 'Health', 58500],
    [10, 'bKash Recharge', 'Mobile', 50000],
    [11, 'Pathao Ride', 'Transport', 16500],
    [12, 'Meena Bazar', 'Groceries', 189000],
    [13, 'Chillox', 'Dining', 84000],
    [14, 'Uber', 'Transport', 31000],
    [15, "Gloria Jean's Coffee", 'Dining', 52000],
    [17, 'bKash Recharge', 'Mobile', 50000],
    [18, 'Star Kabab', 'Dining', 76000],
    [19, 'Uber', 'Transport', 22500],
    [20, 'Meena Bazar', 'Groceries', 161000],
    [21, 'Cineplex', 'Entertainment', 80000],
    [22, 'Meena Bazar', 'Groceries', 180915, 'receipt', 0.93],
    [23, 'Pathao Ride', 'Transport', 17500],
    [24, 'Link3 Internet', 'Utilities', 120000],
    [25, 'bKash Recharge', 'Mobile', 50000],
    [26, 'Uber', 'Transport', 29500],
    [27, 'Star Kabab', 'Dining', 108100, 'receipt', 0.9],
    [28, 'Meena Bazar', 'Groceries', 133500],
  ];
  for (const [day, shop, category, amountPaisa, source, confidence] of thisRows) {
    rows.push({ date: iso(d(now, dayThis(day))), shop, category, amountPaisa, source, confidence });
  }
  if (daysThis >= 2) rows.push({ date: today, shop: 'Uber', category: 'Transport', amountPaisa: 24000 });

  // ---- Pockets
  const pockets = [
    { name: 'ASUS Laptop', itemDetails: 'ASUS Vivobook 15 — Core i5, 16GB RAM (Star Tech)', targetPaisa: 8500000, savedPaisa: 1850000, monthlyContributionPaisa: 600000, dpsRate: 9.5 },
    { name: 'Wedding Fund', itemDetails: 'Family ceremony & hall advance', targetPaisa: 30000000, savedPaisa: 4500000, monthlyContributionPaisa: 800000, dpsRate: 9.5 },
    { name: 'Emergency Fund', itemDetails: 'Six months of living costs', targetPaisa: 12000000, savedPaisa: 6600000, monthlyContributionPaisa: 500000, dpsRate: 9.5 },
  ];

  await db.expense.deleteMany({});
  await db.pocket.deleteMany({});
  await db.settings.upsert({ where: { id: 1 }, update: { monthlySalary: 4500000 }, create: { id: 1, monthlySalary: 4500000 } });
  await db.expense.createMany({
    data: rows.map(r => ({
      date: new Date(`${r.date}T12:00:00.000Z`),
      shop: r.shop,
      category: r.category,
      amountPaisa: r.amountPaisa,
      source: r.source ?? 'manual',
      confidence: r.confidence ?? null,
    })),
  });
  await db.pocket.createMany({ data: pockets });

  return NextResponse.json({ ok: true, inserted: rows.length, pockets: pockets.length });
}
