import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET() {
  const [settings] = await db.settings.findMany({ where: { id: 1 } });
  const expenses = await db.expense.findMany({ orderBy: [{ date: 'desc' }, { id: 'desc' }] });
  const pockets = await db.pocket.findMany({ orderBy: { id: 'asc' } });
  return NextResponse.json({
    salaryPaisa: settings?.monthlySalary ?? 0,
    expenses: expenses.map(e => ({
      id: e.id,
      date: e.date.toISOString().slice(0, 10),
      shop: e.shop,
      category: e.category,
      amountPaisa: e.amountPaisa,
      source: e.source,
      confidence: e.confidence,
    })),
    pockets,
  });
}
