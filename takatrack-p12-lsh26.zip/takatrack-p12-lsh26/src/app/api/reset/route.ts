import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function POST() {
  await db.expense.deleteMany({});
  await db.pocket.deleteMany({});
  await db.settings.deleteMany({ where: { id: 1 } });
  return NextResponse.json({ ok: true });
}
