import { NextRequest, NextResponse } from 'next/server';
import { execFile } from 'child_process';
import { promisify } from 'util';
import { writeFile, unlink, mkdtemp } from 'fs/promises';
import { tmpdir } from 'os';
import path from 'path';
import { parseOcrTsv } from '@/lib/ocr-parse';

const execFileAsync = promisify(execFile);

export const dynamic = 'force-dynamic';
export const maxDuration = 60;

export async function POST(req: NextRequest) {
  let dir: string | null = null;
  try {
    const body = await req.json().catch(() => null);
    const dataUrl = typeof body?.imageBase64 === 'string' ? body.imageBase64 : '';
    const b64 = dataUrl.includes(',') ? dataUrl.slice(dataUrl.indexOf(',') + 1) : dataUrl;
    if (!b64 || b64.length < 100 || b64.length > 15_000_000) {
      return NextResponse.json({ error: 'Image missing or too large (max ~10MB)' }, { status: 400 });
    }
    const buf = Buffer.from(b64, 'base64');
    if (buf.length < 100) return NextResponse.json({ error: 'Invalid image data' }, { status: 400 });

    dir = await mkdtemp(path.join(tmpdir(), 'ocr-'));
    const filePath = path.join(dir, 'receipt.png');
    await writeFile(filePath, buf);

    // Real OCR with word-level confidences (TSV). English traineddata.
    const { stdout } = await execFileAsync(
      'tesseract',
      [filePath, 'stdout', '-l', 'eng', '--psm', '6', 'tsv'],
      { timeout: 45_000, maxBuffer: 20 * 1024 * 1024 }
    );
    const result = parseOcrTsv(stdout);
    return NextResponse.json({ ok: true, ...result });
  } catch {
    return NextResponse.json(
      { ok: false, error: 'Could not read this image as a receipt. It may be corrupt or unsupported — you can still add the expense manually.' },
      { status: 422 }
    );
  } finally {
    if (dir) await unlink(dir + '/receipt.png').catch(() => {});
  }
}
