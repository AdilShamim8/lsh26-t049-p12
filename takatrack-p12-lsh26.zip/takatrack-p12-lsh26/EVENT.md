# Event Start Record

- **Team ID:** `LSH26-T###`  <!-- TODO(team): replace with the real ID from the live portal, e.g. LSH26-T049 if that is yours -->
- **Problem ID:** `P12`
- **Repository:** `lsh26-t###-p12`  <!-- TODO(team): match the real repository name -->
- **Event start code:** `<START-CODE>`  <!-- TODO(team): paste the code shown in the live portal at 6:00 PM -->
- **Repository created before release:** No

## Material present before 6:00 PM

No project code, templates, configurations or assets for this problem existed
before the event started. The solution was produced during the event window
with AI coding assistance (declared in `evaluation-manifest.json` →
`ai_tools_used`). The only pre-existing items in the working environment were
the sandbox's generic Next.js/TypeScript starter tooling and standard system
libraries (including the Tesseract OCR binary); no P12-specific logic, data or
UI was present before problem release.

| Material | Source or original location | What was already present |
|---|---|---|
| Generic sandbox starter tooling | Build environment | Empty Next.js/TypeScript scaffold, shadcn/ui component library, Prisma ORM setup — no application code for this problem |
| System Tesseract OCR binary | `tesseract-ocr` package | Standard OCR engine, unmodified |

## Declaration

This file was added in the first event-work commit. The team will preserve the
repository history until results are announced.
