# Third-Party Licenses

TakaTrack (LofiStack Hackathon 2026 — P12, Team ReWoo)

All dependencies below are permissively licensed (MIT / Apache-2.0 / ISC).
No AGPL, GPL, LGPL, MPL, SSPL or copyleft components are used. All assets in
`public/` are original works generated for this project.

## Direct dependencies

| Item | Version | Source | License | Usage |
|---|---|---|---|---|
| next | 16.x | npm | MIT | App framework (App Router, API routes) |
| react / react-dom | 19.x | npm | MIT | UI runtime |
| prisma / @prisma/client | 6.x | npm | Apache-2.0 | SQLite ORM (schema in `prisma/`) |
| tailwindcss | 4.x | npm | MIT | Styling |
| shadcn/ui (New York) + Radix primitives | current | npm (@radix-ui/*) | MIT (shadcn/ui code: MIT; Radix: MIT) | Pre-built accessible components (dialog, select, popover, slider, switch, progress, collapsible, tabs, toast, etc.) in `src/components/ui/` |
| recharts | 2.15.x | npm | MIT | Dashboard donut chart |
| lucide-react | 0.5x | npm | ISC | Icons |
| class-variance-authority | 0.7.x | npm | Apache-2.0 | Component variants |
| clsx | 2.x | npm | MIT | Class merging |
| tailwind-merge | 3.x | npm | MIT | Class merging |
| zod | 4.x | npm | MIT | (available; input validation implemented manually in API routes) |
| Tesseract OCR | 5.5.0 | system package (`tesseract-ocr`) + `eng.traineddata` | Apache-2.0 | Server-side receipt OCR (`POST /api/ocr`) |
| sharp | 0.34.x | npm | Apache-2.0 | Build-time rendering of the sample receipt images in `public/samples/` |
| bun | 1.3.x | bun.sh | MIT | Dev/runtime tooling used to develop and run the app |

## Build/dev tooling (not shipped to users)

| Item | License |
|---|---|
| eslint + eslint-config-next | MIT |
| typescript | Apache-2.0 |
| @types/* | MIT |
| tw-animate-css | MIT |
| tailwindcss-animate | MIT |

## Assets

| Item | Source | License | Usage |
|---|---|---|---|
| Sample receipt images (`public/samples/*.png`) | Generated in-repo by `scripts/gen-receipts.mjs` (sharp/SVG) | Project-original (MIT, same as repo) | Demo inputs for the OCR flow |
| Favicon/app icons | Default scaffold / inline | MIT | UI |

## Notes

- The `z-ai-web-dev-sdk` package present in the sandbox toolchain is **not
  used** by the shipped application (vision chat was evaluated and replaced by
  local Tesseract OCR).
- Transitive npm dependencies carry their own permissive licenses as published
  on the npm registry; no copyleft licenses are introduced by them.
