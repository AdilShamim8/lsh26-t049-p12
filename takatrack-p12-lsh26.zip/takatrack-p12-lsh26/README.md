# TakaTrack — Personal Ledger Manager

**LofiStack Hackathon 2026 · Problem P12 · Team ReWoo**

TakaTrack gives a salaried person in Dhaka one place to record spending with as
little typing as possible, see where the money went, know what the rest of the
month looks like, and put a **real, forecast-based completion date** on every
savings goal.

## Problem

Bills sit on paper and mobile-money receipts live as screenshots, so spending
only gets reviewed when it is too late to adjust. Savings goals have no dates
attached. P12 asks for a ledger that fixes this end-to-end: receipt-image entry
with honest OCR, a monthly dashboard, a rest-of-month forecast with numeric
insights, and savings pockets priced by the forecast — including what a bank
DPS would return over the same period.

## Solution

A single Next.js application backed by SQLite (Prisma). All financial logic
lives in one **pure, deterministic engine** (`src/lib/engine.ts`); AI/OCR is
only used for reading receipts (Tesseract 5, word-level confidences), never
for math. Every dashboard number, insight, pocket date and DPS figure is
recomputed from the raw ledger on every change — nothing is cached, nothing is
hard-coded.

## Key features (mapped to scored requirements)

| Requirement | Where to verify | How it works |
|---|---|---|
| **R1 — Receipt/image entry** | `Add Expense` tab | Set salary in the header; add expenses manually or upload a receipt photo (or click one of the three sample bills). On-device Tesseract OCR extracts **amount, date, shop** with per-field confidence badges. Uncertain/missing fields are flagged amber/red and **must** be corrected by the user — the app never invents a value. Fields stay editable until “Save receipt expense”. |
| **R2 — Monthly dashboard** | `Dashboard` tab | Total spent vs salary (progress), category breakdown (donut + share list), largest expenses, and change vs last month (amount + %). |
| **R3 — Forecast + insights** | `Dashboard` right column | Run-rate forecast: `spent + (spent/days elapsed) × days left`, expected money left **or shortfall** at month end, plus five insights that name specific categories and amounts. Insights are a pure function of the data — delete an expense and watch them change instantly. |
| **R4 — Savings pockets** | `Savings Pockets` tab | Pockets (name, item details, target, monthly contribution). Completion date = today + ⌈remaining ÷ **forecast-adjusted** contribution⌉ where the adjustment is `salary − projected month-end spend`, rationed proportionally when pockets over-plan. Each card shows the naive `target ÷ contribution` date crossed out, labelled “N months too optimistic”. DPS panel states the rate and method (`FV = P × ((1+i)^n − 1)/i`, monthly compounding) and returns maturity = deposits + interest over the forecast horizon. |

### Bonus features (all three)

1. **Contribution slider** — edit a pocket's monthly contribution and every
   completion date moves immediately.
2. **Recurring detection** — shops appearing in two consecutive months with
   amounts within ±15% are detected automatically (dashboard badge + insight).
3. **What-if** — per-category cut sliders (0–50%) recompute the surplus and
   move **every pocket date** live, with per-pocket “scenario” badges.

## How to run

```bash
# prerequisites: Node 20+ / Bun, and the Tesseract OCR binary
#   Ubuntu/Debian: sudo apt install tesseract-ocr
#   macOS:         brew install tesseract

bun install                # or npm install
cp .env.example .env       # points DATABASE_URL at ./db/custom.db
bun run db:push            # create the SQLite schema
bun run dev                # http://localhost:3000
```

Then click **Load demo data** in the header (seeds salary ৳45,000, ~52
expenses across two months, and three savings pockets), or start empty and add
your own. **Reset** clears everything.

## Live demo

Deployed URL is recorded in `evaluation-manifest.json` (`live_url`) and on the
submission form. The app requires no login and no configuration; demo data
loads with one click.

## Sample data / judge reset

- **Load demo data** (header) — seeds the full two-month dataset at any time.
- **Reset** (header) — wipes all expenses, pockets and salary.
- Judges can also verify OCR without a receipt image: the `Add Expense` tab
  ships three built-in sample bills that run through the real OCR pipeline.

## What is mocked

Nothing functional. Specifics worth stating honestly:

- **OCR** is real (Tesseract 5.5 server-side, word-level confidence), not a
  canned response. It runs on any uploaded image.
- **Sample receipt images** (`public/samples/*.png`) are generated demo assets
  (rendered bill scans), clearly footed “LofiStack P12 sample receipt”.
- There is **no bank/bKash API integration** — “recurring detection” is
  computed from the ledger data, and DPS figures are illustrative calculations
  at the stated rate, not quotes.

## What we would build next

1. Multi-user auth and cloud sync (currently a single shared ledger).
2. Bengali + English receipt OCR (currently `eng` traineddata) and camera
   capture on mobile.
3. Historical trends (6–12 month charts) and budget envelopes per category.
4. Real DPS/bank product feeds and inflation-aware goal targets.
5. Export to CSV/PDF month-end reports.

## Known limitations

- Single shared dataset (no per-user isolation) — fine for judging, not for
  production.
- OCR accuracy drops on crumpled photos or handwriting; low confidence is
  surfaced rather than hidden, but recognition itself is English-only.
- Pocket dates assume the forecast surplus repeats monthly until the goal is
  met (no salary-growth or seasonal modelling).
- The demo dataset is generated relative to “today” so comparisons always have
  a live month — amounts are illustrative, not real bank data.
